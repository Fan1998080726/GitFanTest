package org.jeecgframework.web.cgform.exception;

@SuppressWarnings("serial")
public class DBException extends Exception {
	
	public DBException(String msg)
	 {
	  super(msg);
	 }
}
