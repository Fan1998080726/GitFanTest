package org.jeecgframework.tag.vo.easyui;
/**
* 列表操作类型
* @author  张代浩
*/
public enum OptTypeDirection {
	Deff,Del,Fun,OpenWin,Confirm,ToolBar,OpenTab
	
}
