/* 禁止右键begin */
	 function stop(){ 
	return false; 
	} 
	//document.oncontextmenu=stop;  
	/* 禁止右键end */